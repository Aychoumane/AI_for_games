#include <iostream>
#include <unordered_map>
#include <string>

struct couple_t{
    int wi ;
    int ni ; 
};


class Myhashmap {
private:
    std::unordered_map<std::string, couple_t> hashMap;
    int nb_element = 0 ; 

public:
    // Méthode pour ajouter un élément à la hashmap
    void ajouterElement(const std::string& cle, couple_t valeur) {
        hashMap[cle] = valeur;
        nb_element++ ;
    }

    // Méthode pour retirer un élément de la hashmap
    void retirerElement(const std::string& cle) {
        auto it = hashMap.find(cle);
        if (it != hashMap.end()) {
            hashMap.erase(it);
            std::cout << "Element avec la clé '" << cle << "' retiré avec succès." << std::endl;
            nb_element-- ; 
        } else {
            std::cerr << "La clé '" << cle << "' n'existe pas dans la hashmap." << std::endl;
        }
    }

    // Méthode pour accéder à un élément de la hashmap
    couple_t obtenirElement(const std::string& cle) {
        auto it = hashMap.find(cle);
        if (it != hashMap.end()) {
            return it->second; // Utilisez it->second pour accéder à la valeur associée à la clé
        } else {
            std::cerr << "La clé '" << cle << "' n'existe pas dans la hashmap." << std::endl;
            return {0, 0}; // ou une valeur par défaut appropriée
        }
    }

    // Méthode pour vérifier si une clé existe dans la hashmap
    bool existeElement(const std::string& cle) {
        return hashMap.find(cle) != hashMap.end();
    }

    void print_nb_elem(){
        std::cout << this->nb_element << std::endl ; 
    }
};

int main() {
    // Utilisation de la classe CustomHashMap
    Myhashmap maHashMap;
    couple_t a = {3,2} ; 
    printf("%d %d \n", a.wi , a.ni ) ; 
    // Ajout d'éléments
    maHashMap.ajouterElement("Bonjour", a);
    /*maHashMap.ajouterElement("Monde", 2);
    maHashMap.ajouterElement("C++", 3);
*/
    // Vérifier si un élément existe
    std::cout << "Est-ce que 'Bonjour' existe ? " << (maHashMap.existeElement("Bonjour") ? "Oui" : "Non") << std::endl;
    std::cout << "Est-ce que 'Python' existe ? " << (maHashMap.existeElement("Python") ? "Oui" : "Non") << std::endl;
    maHashMap.print_nb_elem(); 
    maHashMap.retirerElement("Bonjour") ; 
    maHashMap.print_nb_elem(); 
    std::cout << "Est-ce que 'Bonjour' existe ? " << (maHashMap.existeElement("Bonjour") ? "Oui" : "Non") << std::endl;
    couple_t b =  maHashMap.obtenirElement("Bonjour");
    std::cout << b.ni << b.wi << std::endl ; 
    return 0;
}
