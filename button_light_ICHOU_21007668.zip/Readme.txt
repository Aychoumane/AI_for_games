						//////////////////////////////////////////////
						/// TP3 datalog : ICHOU AYMANE L3X 21007668/// 
						//////////////////////////////////////////////


Règles du jeu : 

Le jeu buttons and lights est un jeu avec des lampes et des boutons.
Les boutons agissent sur les lampes.
Dans la version classique, l'objectif est d'allumer toutes les lampes.
On commencera par le jeu à 3 lampes. On évoluera ensuite vers le jeu à N lampes. On pourrait jouer à 1 ou plusieurs joueurs, mais on se limitera à la version à 1 joueur.
On représentera les lampes par des valeurs 0 et 1.
0 est une lampe éteinte.
1 est une lampe allumée.
Pour le jeu à 3 lampes, 0 0 0 représente 3 lampes éteintes.

Le premier bouton allume ou éteint la première lampe.
Les boutons suivants copie la lampe précédente dans la lampe suivante et éteint la lampe précédente.

Partant de 0 0 0, appuyer sur le premier bouton donne 1 0 0
Partant de 1 0 0, appuyer sur le premier bouton donne 0 0 0

Partant de 1 0 0, appuyer sur le deuxième bouton donne 0 1 0
Partant de 0 1 0, appuyer sur le deuxième bouton donne 0 0 0

Partant de 0 1 0, appuyer sur le troisième bouton donne 0 0 1
Partant de 0 0 1, appuyer sur le troisième bouton donne 0 0 0

Partant d'un problème, il s'agit de trouver la séquence qui allume toutes les lampes.
On pourra noter les lampes 1 2 3.
Ainsi partant de 0 0 0, la solution la plus courte est 1 2 3 1 2 1

L'objectif de ce TP est d'écrire le programme qui résoud le jeu "Buttons and Lights".

Ce que mon programme fait: 

-----------------------------------
Quand on pose la question :
 (? (next 0 1 1 1 '() A B C X Y))
Le programme répond :
 next(0, 1, 1, 1, '(), 1, 1, 1, 0, '(a)).
 next(0, 1, 1, 1, '(), 0, 0, 1, 0, '(b)).
 next(0, 1, 1, 1, '(), 0, 0, 1, 0, '(c)).

-----------------------------------
Quand on pose les questions :
 ? (end 1 1 1 X))
 ? (end 0 1 0 X))
Le programme répond :
 end(1, 1, 1, #t).
 end(0, 1, 0, #f).
 
-----------------------------------
Ma fonction eval prend un paramètre en plus qui est une liste vide mais répond comme demandé dans l'énoncé.
Quand on pose la question :
  (? (eval 0 0 0 7 X '() )) au lieu de (? (eval 0 0 0 7 X)) dans l'énoncé.
Le programme répond : 
 eval(0, 0, 0, 7, '(a b a c b a)).
 eval(0, 0, 0, 7, '(a b c a b a)).
 Et d'autres solutions.

J'ai résolu la version classique à 1 joueur.
Des exemples en commentaire ont été laissé à la fin du code pour faciliter les tests. 

